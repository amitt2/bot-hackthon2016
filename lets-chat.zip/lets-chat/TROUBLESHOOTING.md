# Common Issues

We'll be improving this document soon.

#### What version of Node.JS is required?

Let's Chat requires Node.JS version ```0.10.x``` or ```0.12.x```. You will have a bad time if you try to use a different version.

#### Do I need MongoDB running?

Yes. Please refer to [MongoDB's documentation](http://docs.mongodb.org/manual/).
