//
// Middlewares
//

'use strict';

var requireDirectory = require('require-directory');

module.exports = requireDirectory(module);
